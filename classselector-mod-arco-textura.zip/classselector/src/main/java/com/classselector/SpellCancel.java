package com.classselector;

import com.mojang.logging.LogUtils;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TraceableEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraftforge.registries.ForgeRegistries;
import org.slf4j.Logger;

import java.lang.reflect.Method;
import java.util.List;

/**
 * Cancela feitiços do Iron's Spells 'n Spellbooks.
 * O mod não depende do Iron's em tempo de compilação, então a interrupção de conjuração usa reflexão
 * (nomes testados nas versões 3.x para 1.20.1). Se algo não for encontrado, avisa uma vez no log e segue sem erro.
 */
public final class SpellCancel {
    private static final Logger LOG = LogUtils.getLogger();
    private static final String IRONS = "irons_spellbooks";

    private static boolean ready = false;
    private static boolean warned = false;
    private static Method cancelPlayer;        // Utils.serverSideCancelCast(ServerPlayer[, boolean])
    private static boolean cancelPlayerHasFlag;
    private static Method cancelMob;           // AbstractSpellCastingMob.cancelCast()
    private static Class<?> mobClass;
    private static Method getMagicData;        // MagicData.getPlayerMagicData(LivingEntity)
    private static Method isCasting;           // MagicData.isCasting()

    private SpellCancel() { }

    private static Class<?> find(String... names) {
        for (String n : names) {
            try { return Class.forName(n); } catch (Throwable ignored) { }
        }
        return null;
    }

    private static synchronized void init() {
        if (ready) return;
        ready = true;
        try {
            Class<?> utils = find("io.redspace.ironsspellbooks.api.util.Utils", "io.redspace.ironsspellbooks.util.Utils");
            if (utils != null) {
                for (Method m : utils.getMethods()) {
                    if (!m.getName().equals("serverSideCancelCast")) continue;
                    Class<?>[] p = m.getParameterTypes();
                    if (p.length >= 1 && p[0] == ServerPlayer.class) {
                        // prefere a versão simples (só o jogador)
                        if (cancelPlayer == null || p.length == 1) {
                            cancelPlayer = m;
                            cancelPlayerHasFlag = p.length == 2 && p[1] == boolean.class;
                        }
                    }
                }
            }
            mobClass = find("io.redspace.ironsspellbooks.entity.mobs.abstract_spell_casting_mob.AbstractSpellCastingMob");
            if (mobClass != null) {
                try { cancelMob = mobClass.getMethod("cancelCast"); } catch (Throwable ignored) { }
            }
            Class<?> md = find("io.redspace.ironsspellbooks.api.magic.MagicData");
            if (md != null) {
                try { getMagicData = md.getMethod("getPlayerMagicData", LivingEntity.class); } catch (Throwable ignored) { }
                try { isCasting = md.getMethod("isCasting"); } catch (Throwable ignored) { }
            }
        } catch (Throwable t) {
            warn("falha ao localizar a API do Iron's Spellbooks", t);
        }
        if (cancelPlayer == null && cancelMob == null) {
            warn("API de cancelar conjuração do Iron's Spellbooks não encontrada (versão diferente?)", null);
        }
    }

    private static void warn(String msg, Throwable t) {
        if (warned) return;
        warned = true;
        if (t != null) LOG.warn("[classselector] {}", msg, t); else LOG.warn("[classselector] {}", msg);
    }

    /** true se o alvo está conjurando agora (se não der para saber, assume que sim). */
    private static boolean casting(LivingEntity e) {
        if (getMagicData == null || isCasting == null) return true;
        try {
            Object data = getMagicData.invoke(null, e);
            return data == null || (Boolean) isCasting.invoke(data);
        } catch (Throwable t) {
            return true;
        }
    }

    /** Interrompe a magia que {@code e} está conjurando. Retorna true se uma conjuração foi cancelada. */
    public static boolean interrupt(LivingEntity e) {
        if (e.level().isClientSide) return false;
        init();
        try {
            if (!casting(e)) return false;
            if (e instanceof ServerPlayer sp && cancelPlayer != null) {
                if (cancelPlayerHasFlag) cancelPlayer.invoke(null, sp, false); else cancelPlayer.invoke(null, sp);
                return true;
            }
            if (mobClass != null && cancelMob != null && mobClass.isInstance(e)) {
                cancelMob.invoke(e);
                return true;
            }
        } catch (Throwable t) {
            warn("erro ao cancelar a conjuração de " + e.getName().getString(), t);
        }
        return false;
    }

    private static boolean isSpellEntity(Entity x) {
        if (x instanceof LivingEntity || x instanceof ItemEntity) return false;
        ResourceLocation id = ForgeRegistries.ENTITY_TYPES.getKey(x.getType());
        return id != null && IRONS.equals(id.getNamespace());
    }

    /** Remove projéteis e áreas mágicas do Iron's Spells (que não sejam de {@code owner}) no raio. Retorna quantos. */
    public static int dispelEntities(Level level, LivingEntity owner, double radius) {
        AABB box = owner.getBoundingBox().inflate(radius);
        List<Entity> list = level.getEntities(owner, box, x -> isSpellEntity(x)
                && !(x instanceof TraceableEntity t && t.getOwner() == owner)
                && x.distanceToSqr(owner) <= radius * radius);
        for (Entity x : list) x.discard();
        return list.size();
    }
}
