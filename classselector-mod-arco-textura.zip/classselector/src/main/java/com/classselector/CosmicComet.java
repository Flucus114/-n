package com.classselector;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.DragonFireball;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;

/**
 * Cometa Cósmico: o projétil do Soberano Cósmico (substitui as bolas de fogo do dragão e os
 * orbes teleguiados). Comporta-se como a bola do dragão (explode numa nuvem de sopro de dragão),
 * mas é desenhado como um cometa 3D roxo (ver {@link CosmicCometRenderer}).
 * A variante teleguiada persegue o alvo, causa dano direto e aplica levitação ao acertar.
 */
public class CosmicComet extends DragonFireball {
    /** Velocidade (blocos/tick) do cometa comum e do teleguiado. */
    public static final double SPEED = 0.85D, HOMING_SPEED = 0.6D;
    private static final int MAX_LIFE = 200;

    /** Só no cliente: direção suavizada do voo (a frente do modelo aponta para ela). */
    private Vec3 viewDir = null, viewDirO = null;

    @Nullable private LivingEntity homingTarget;
    private boolean homing = false;
    private int homingTicks = 0;

    public CosmicComet(EntityType<? extends CosmicComet> type, Level level) {
        super(type, level);
    }

    /** Cometa comum, disparado na direção (dx, dy, dz). */
    public static CosmicComet create(Level level, LivingEntity owner, Vec3 pos, Vec3 dir) {
        CosmicComet c = new CosmicComet(ModEntities.COSMIC_COMET.get(), level);
        c.setOwner(owner);
        c.launch(pos, dir, SPEED);
        return c;
    }

    /** Cometa teleguiado que persegue {@code target}. */
    public static CosmicComet createHoming(Level level, LivingEntity owner, Vec3 pos, LivingEntity target) {
        CosmicComet c = new CosmicComet(ModEntities.COSMIC_COMET.get(), level);
        c.setOwner(owner);
        c.homing = true;
        c.homingTarget = target;
        c.launch(pos, target.getBoundingBox().getCenter().subtract(pos), HOMING_SPEED);
        return c;
    }

    private void launch(Vec3 pos, Vec3 dir, double speed) {
        Vec3 d = dir.lengthSqr() < 1.0E-6D ? new Vec3(0.0D, 0.0D, 1.0D) : dir.normalize();
        this.setPos(pos.x, pos.y, pos.z);
        this.setDeltaMovement(d.scale(speed));
        float yaw = (float) (Mth.atan2(d.x, d.z) * 57.2957795D);
        float pitch = (float) (Mth.atan2(d.y, Math.sqrt(d.x * d.x + d.z * d.z)) * 57.2957795D);
        this.setRot(yaw, pitch);
        this.yRotO = yaw;
        this.xRotO = pitch;
    }

    /** Velocidade constante (sem o atrito de 5% por tick da bola de fogo comum). */
    @Override
    protected float getInertia() {
        return 1.0F;
    }

    /** Direção (unitária) para onde o cometa está indo, interpolada entre ticks. Só faz sentido no cliente. */
    public Vec3 getViewDir(float pt) {
        if (viewDir == null) {
            Vec3 dm = getDeltaMovement();
            return dm.lengthSqr() > 1.0E-6D ? dm.normalize() : new Vec3(0.0D, 0.0D, 1.0D);
        }
        Vec3 v = viewDirO.lerp(viewDir, pt);
        return v.lengthSqr() > 1.0E-6D ? v.normalize() : viewDir;
    }

    private void updateViewDir() {
        Vec3 dm = getDeltaMovement();
        if (dm.lengthSqr() < 1.0E-4D) return;
        Vec3 target = dm.normalize();
        if (viewDir == null) {
            viewDir = target;
            viewDirO = target;
            return;
        }
        viewDirO = viewDir;
        Vec3 mixed = viewDir.lerp(target, 0.4D);
        viewDir = mixed.lengthSqr() > 1.0E-6D ? mixed.normalize() : target;
    }

    @Override
    public void tick() {
        if (level().isClientSide) {
            updateViewDir();
            // rastro de brilho estelar (além do sopro de dragão da bola original)
            for (int i = 0; i < 2; i++) {
                level().addParticle(ParticleTypes.PORTAL, getRandomX(0.6D), getRandomY(), getRandomZ(0.6D),
                        0.0D, 0.0D, 0.0D);
            }
            if (tickCount % 3 == 0) {
                level().addParticle(ParticleTypes.END_ROD, getRandomX(0.5D), getRandomY(), getRandomZ(0.5D),
                        0.0D, 0.0D, 0.0D);
            }
        } else {
            if (tickCount > MAX_LIFE) {
                discard();
                return;
            }
            if (homingTarget != null) {
                if (++homingTicks > 140 || !homingTarget.isAlive()) {
                    homingTarget = null;      // perdeu o alvo: segue em linha reta
                } else {
                    Vec3 want = homingTarget.getBoundingBox().getCenter().subtract(position())
                            .normalize().scale(HOMING_SPEED);
                    setDeltaMovement(getDeltaMovement().lerp(want, 0.12D));
                }
            }
        }
        super.tick();
    }

    @Override
    protected void onHit(HitResult result) {
        if (!homing) {
            super.onHit(result);          // nuvem de sopro de dragão, como antes
            return;
        }
        if (!level().isClientSide) {
            if (result instanceof EntityHitResult ehr) {
                Entity hit = ehr.getEntity();
                if (!ownedBy(hit)) {
                    Entity owner = getOwner();
                    LivingEntity lo = owner instanceof LivingEntity l ? l : null;
                    if (hit.hurt(damageSources().indirectMagic(this, lo), 4.0F) && hit instanceof LivingEntity le) {
                        le.addEffect(new MobEffectInstance(MobEffects.LEVITATION, 200), owner);
                    }
                }
            }
            ((ServerLevel) level()).sendParticles(ParticleTypes.END_ROD, getX(), getY(), getZ(), 20, 0.3, 0.3, 0.3, 0.08);
            playSound(SoundEvents.SHULKER_BULLET_HIT, 1.0F, 0.8F);
            discard();
        }
    }
}
