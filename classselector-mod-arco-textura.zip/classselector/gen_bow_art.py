#!/usr/bin/env python3
"""Gera o Hyper Arco de Sculk a partir da arte do usuário (modelsrc/hyper_arco_textura_referencia.png).
Peças usadas: corpo/olho (A), asa traseira (B), explosão do olho (estrela) e corda (esferas luminosas).
Saída: textures/item/hyper_sculk_bow.png (416x416) e models/item/hyper_sculk_bow*.json
UVs em escala 0..16 (padrão do Minecraft; texture_size NÃO é usado pelo jogo)."""
import json, os, math
import numpy as np
from PIL import Image
from scipy import ndimage as ndi

ROOT = os.path.dirname(os.path.abspath(__file__))
RES = os.path.join(ROOT, "src/main/resources/assets/classselector")
SRC = Image.open(os.path.join(ROOT, "modelsrc/hyper_arco_textura_referencia.png")).convert("RGB")
NAME = "hyper_sculk_bow"
N = 400; T = 416                      # arte 400x400 + faixa de 16px para os tiles pequenos
K = N / SRC.size[0]                    # px original -> px atlas

# ---------- atlas com transparência ----------
a = np.array(SRC).astype(float)
lum = a @ [0.299, 0.587, 0.114]
dark = lum <= 16
lab, n = ndi.label(dark)
border = set(lab[0, :]) | set(lab[-1, :]) | set(lab[:, 0]) | set(lab[:, -1]); border.discard(0)
bg = np.isin(lab, list(border))
bg = ndi.binary_dilation(bg, iterations=1) & (lum <= 30)
alpha = np.where(bg, 0.0, 1.0)
pre = np.dstack([a * alpha[..., None], alpha * 255])
big = Image.fromarray(np.clip(pre, 0, 255).astype(np.uint8), "RGBA")      # premultiplicado
small = np.array(big.resize((N, N), Image.BOX)).astype(float)
al = small[..., 3] / 255.0
rgb = np.where(al[..., None] > 0, small[..., :3] / np.maximum(al[..., None], 1e-6), 0)
out = np.zeros((T, T, 4), np.uint8)
out[:N, :N, :3] = np.clip(rgb, 0, 255).astype(np.uint8)
out[:N, :N, 3] = np.where(al > 0.5, 255, 0)
rng = np.random.RandomState(7)
def tile(x0, base, dots, dotc, noise=0):
    t = np.zeros((16, 16, 4), np.uint8); t[..., :3] = base; t[..., 3] = 255
    if noise:
        m = rng.rand(16, 16) < noise; t[m, :3] = dotc
    for (x, y) in dots: t[y:y + 2, x:x + 2, :3] = dotc
    out[N:N + 16, x0:x0 + 16] = t
tile(0, (9, 221, 243), [(3, 3), (10, 9)], (223, 251, 252))          # corda
tile(16, (205, 252, 255), [], (255, 255, 255), 0.15)                # halo
tile(32, (14, 22, 36), [], (27, 38, 58), 0.25)                      # espinha escura
Image.fromarray(out, "RGBA").save(os.path.join(RES, "textures/item", NAME + ".png"))
Image.fromarray(out, "RGBA").save(os.path.join(ROOT, "modelsrc/hyper_arco_sculk_texture.png"))

def uv(px0, py0, px1, py1, k=K):      # px do atlas -> 0..16
    return [round(px0 * k / T * 16, 4), round(py0 * k / T * 16, 4), round(px1 * k / T * 16, 4), round(py1 * k / T * 16, 4)]
def uvt(x0):                          # tile pequeno (já em px de atlas)
    return [round(x0 / T * 16, 4), round(N / T * 16, 4), round((x0 + 16) / T * 16, 4), 16.0]

# ---------- geometria ----------
Y0, Y1 = -3.5, 19.5                   # eixo do arco (23 unidades)
S = 23.0 / 1145                       # unidades por px original
A = (22, 309, 22, 1167); B = (356, 586, 32, 1180); STAR = (526, 746, 327, 748)
def blob(x0, x1, y0, y1):
    r = (a[y0:y1, x0:x1] @ [0.299, 0.587, 0.114]) > 225
    ys, xs = np.nonzero(r); return xs.mean() + x0, ys.mean() + y0
EA = blob(100, 200, 500, 640); ES = blob(580, 700, 460, 600)
print("olho A", EA, "olho estrela", ES)

def xc(t): return 3.6 + 3.4 * (1 - (2 * t - 1) ** 2)       # curva do corpo
def ytot(y): return (y - Y0) / (Y1 - Y0)
ROT = {"angle": 45, "axis": "z", "origin": [8, 8, 8]}
def r4(v): return round(v, 4)
def sliced(box, z, n, ytop_px, ytop_w, s, ax, dx=0.0):
    """plano em fatias que acompanham a curva. y mundo = ytop_w - (py-ytop_px)*s ; x mundo = xc + (px-ax)*s + dx"""
    x0, x1, y0, y1 = box; els = []
    h = (y1 - y0) / n
    for j in range(n):
        pa, pb = y0 + j * h, y0 + (j + 1) * h
        yhi = ytop_w - (pa - ytop_px) * s; ylo = ytop_w - (pb - ytop_px) * s
        c = xc(ytot((yhi + ylo) / 2))
        xl = c + (x0 - ax) * s + dx; xh = c + (x1 - ax) * s + dx
        u = uv(x0, pa, x1, pb)
        els.append({"from": [r4(xl), r4(ylo), z], "to": [r4(xh), r4(yhi), z], "rotation": ROT,
                    "faces": {"south": {"uv": u, "texture": "#0"}, "north": {"uv": u, "texture": "#0"}}})
    return els

ycen = Y1 - (EA[1] - 22) * S                       # y mundo do olho
body_A = sliced(A, 8.45, 28, 22, Y1, S, (22 + 309) / 2)
SB = 23.0 / 1148
body_B = sliced(B, 7.4, 28, 32, Y1, SB, (356 + 586) / 2, dx=0.0)
eye_dx = (EA[0] - (22 + 309) / 2) * S              # olho de A fica um pouco à esquerda do centro
star = sliced(STAR, 8.6, 12, ES[1], ycen, S * 1.4, ES[0], dx=eye_dx)
# a estrela é fatiada em torno do olho: x = xc(t) + (px-ES)*S + eye_dx
spine = []
nsp = 24; hs = (Y1 - Y0) / nsp
for j in range(nsp):
    ylo = Y0 + j * hs; yhi = ylo + hs; c = xc(ytot((ylo + yhi) / 2)) + eye_dx * 0.5
    f = {d: {"uv": uvt(32), "texture": "#0"} for d in ("north", "east", "south", "west", "up", "down")}
    spine.append({"from": [r4(c - 0.5), r4(ylo), 7.7], "to": [r4(c + 0.5), r4(yhi), 8.3], "rotation": ROT, "faces": f})

def cube(a_, b_, x0):
    f = {d: {"uv": uvt(x0), "texture": "#0"} for d in ("north", "east", "south", "west", "up", "down")}
    return {"from": [r4(v) for v in a_], "to": [r4(v) for v in b_], "rotation": ROT, "faces": f}
SY0, SY1 = Y0 + 0.2, Y1 - 0.2; SX = 5.0; G = 0.4
def string(shift_vox, halo):
    els = []; n = int(round((SY1 - SY0) / G)); mid = n / 2; half = n / 2
    sh = [int(round(shift_vox * (1 - abs(k + 0.5 - mid) / half))) for k in range(n)]
    k = 0
    while k < n:
        k2 = k
        while k2 + 1 < n and sh[k2 + 1] == sh[k]: k2 += 1
        off = sh[k] * G
        els.append(cube([SX - 0.2 - off, SY0 + k * G, 8.9], [SX + 0.2 - off, SY0 + (k2 + 1) * G, 9.3], 0))
        k = k2 + 1
    if halo:
        ex = xc(ytot(ycen)) + eye_dx
        for dx, dy in [(3.2, 0), (-3.2, 0), (0, 3.2), (0, -3.2), (2.3, 2.3), (-2.3, 2.3), (2.3, -2.3), (-2.3, -2.3)]:
            els.append(cube([ex + dx - .6, ycen + dy - .6, 7.4], [ex + dx + .6, ycen + dy + .6, 8.6], 16))
    return els

S3, S1, SG = 1.1, 0.8, 0.78
DISPLAY = {
    "thirdperson_righthand": {"rotation": [-80, 260, -40], "translation": [-1, -2, 2.5], "scale": [S3] * 3},
    "thirdperson_lefthand":  {"rotation": [-80, -280, 40], "translation": [-1, -2, 2.5], "scale": [S3] * 3},
    "firstperson_righthand": {"rotation": [0, -90, 25], "translation": [1.13, 3.2, 1.13], "scale": [S1] * 3},
    "firstperson_lefthand":  {"rotation": [0, 90, -25], "translation": [1.13, 3.2, 1.13], "scale": [S1] * 3},
    "gui":    {"rotation": [0, 0, 0], "translation": [0, 0, 0], "scale": [SG] * 3},
    "fixed":  {"rotation": [0, 0, 0], "translation": [0, 0, 0], "scale": [SG] * 3},
    "ground": {"rotation": [0, 0, 0], "translation": [0, 3, 0], "scale": [0.7] * 3},
}
def model(shift, halo=False, overrides=None):
    els = body_B + spine + body_A + star + string(shift, halo)
    for e in els: assert all(-16 <= v <= 32 for v in e["from"] + e["to"]), e
    m = {"textures": {"0": f"classselector:item/{NAME}", "particle": f"classselector:item/{NAME}"},
         "elements": els, "display": DISPLAY}
    if overrides: m["overrides"] = overrides
    return m
d = os.path.join(RES, "models/item")
def save(nm, m):
    json.dump(m, open(os.path.join(d, nm + ".json"), "w"), separators=(",", ":"))
ov = [{"predicate": {"pulling": 1}, "model": f"classselector:item/{NAME}_pulling_0"},
      {"predicate": {"pulling": 1, "pull": 0.4}, "model": f"classselector:item/{NAME}_pulling_1"},
      {"predicate": {"pulling": 1, "pull": 0.8}, "model": f"classselector:item/{NAME}_pulling_2"},
      {"predicate": {"pulling": 1, "pull": 1.0}, "model": f"classselector:item/{NAME}_pulling_3"}]
save(NAME, model(0, overrides=ov)); save(NAME + "_pulling_0", model(3))
save(NAME + "_pulling_1", model(6)); save(NAME + "_pulling_2", model(9)); save(NAME + "_pulling_3", model(11, True))
print("ok, elementos:", len(model(0)["elements"]))
